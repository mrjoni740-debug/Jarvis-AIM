# JARVIS AI Android App

इस प्रोजेक्ट में ये सुविधाएँ हैं:
- OpenAI और Google Gemini में से provider चुनना
- हिंदी voice input (Android Speech Recognizer)
- हिंदी में उत्तर बोलना (Android Text-to-Speech)
- फोन में इंस्टॉल ऐप्स की सूची दिखाकर ऐप खोलना

## जरूरी बातें
- Android Studio में इस फोल्डर को खोलें और Gradle Sync करें।
- JDK 17 और Android SDK Platform 35 इस्तेमाल करें।
- Run दबाकर अपने Android फोन पर ऐप चलाएँ।
- OpenAI या Gemini की API key संबंधित आधिकारिक डेवलपर पोर्टल से लें। API इस्तेमाल करने पर शुल्क/कोटा लागू हो सकता है।
- API key इस prototype में केवल ऐप की RAM में रहती है; ऐप बंद होने पर दोबारा डालनी होगी।
- यह शुरुआती personal-use prototype है। इसे सार्वजनिक रूप से रिलीज करने से पहले API calls को अपने सुरक्षित backend से चलाएँ। मोबाइल ऐप में रखी API key को पूरी तरह सुरक्षित नहीं माना जा सकता।
- ऐप केवल उपलब्ध Android ऐप्स खोलता है; यह फोन की सुरक्षा सेटिंग्स या निजी डेटा को बिना अनुमति नियंत्रित नहीं करता।

## APK बनाना
Android Studio: Build > Build Bundle(s) / APK(s) > Build APK(s).
APK आमतौर पर `app/build/outputs/apk/debug/app-debug.apk` में बनेगा।
