# JARVIS AI Android App

इस प्रोजेक्ट में ये सुविधाएँ हैं:
- OpenAI और Google Gemini में से provider चुनना
- हिंदी voice input (Android Speech Recognizer)
- हिंदी में उत्तर बोलना (Android Text-to-Speech)
- फोन में इंस्टॉल ऐप्स की सूची दिखाकर ऐप खोलना

## जरूरी बातें
- Android Studio में इस फोल्डर को खोलें और Gradle Sync करें।
- JDK 17 और Android SDK Platform 35 इस्तेमाल करें।
- Run दबाकर अपने Android फोन पर ऐप चलाएँ।
- OpenAI या Gemini की API key संबंधित आधिकारिक डेवलपर पोर्टल से लें। API इस्तेमाल करने पर शुल्क/कोटा लागू हो सकता है।
- API key इस prototype में केवल ऐप की RAM में रहती है; ऐप बंद होने पर दोबारा डालनी होगी।
- यह शुरुआती personal-use prototype है। इसे सार्वजनिक रूप से रिलीज करने से पहले API calls को अपने सुरक्षित backend से चलाएँ। मोबाइल ऐप में रखी API key को पूरी तरह सुरक्षित नहीं माना जा सकता।
- ऐप केवल उपलब्ध Android ऐप्स खोलता है; यह फोन की सुरक्षा सेटिंग्स या निजी डेटा को बिना अनुमति नियंत्रित नहीं करता।

## APK बनाना
Android Studio: Build > Build Bundle(s) / APK(s) > Build APK(s).
APK आमतौर पर `app/build/outputs/apk/debug/app-debug.apk` में बनेगा।


## मोबाइल से GitHub Actions द्वारा APK बनाना
1. इस ZIP को Extract करें।
2. GitHub पर `Jarvis-AI` नाम से नया **Public या Private** repository बनाएँ।
3. Extract किए गए प्रोजेक्ट की सभी फाइलें और `.github` छिपा हुआ फोल्डर भी अपलोड करें। बेहतर है GitHub वेबसाइट पर `Add file > Upload files` से सभी फाइलें अपलोड करें।
4. फाइलें `main` branch में commit करें।
5. Repository में **Actions** टैब खोलें। `Build JARVIS Android APK` workflow चुनें और `Run workflow` दबाएँ (या main पर push के बाद अपने आप चलेगा)।
6. Build पूरा होने पर workflow run खोलें। नीचे **Artifacts** में `JARVIS-AI-debug-APK` डाउनलोड करें।
7. ZIP artifact को मोबाइल में Extract करें और `app-debug.apk` इंस्टॉल करें। Android पूछे तो केवल अपने भरोसेमंद स्रोत से आई APK के लिए install permission दें।

नोट: GitHub Actions केवल APK build करता है; यह Play Store release/signing नहीं करता। यह debug APK है।
