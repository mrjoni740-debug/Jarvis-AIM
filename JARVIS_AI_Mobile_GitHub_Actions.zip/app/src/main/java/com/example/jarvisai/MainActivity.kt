package com.example.jarvisai

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {
    private val client = OkHttpClient()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private lateinit var provider: Spinner
    private lateinit var apiKey: EditText
    private lateinit var question: EditText
    private lateinit var answer: TextView
    private lateinit var tts: TextToSpeech
    private var ttsReady = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 24)
            gravity = Gravity.CENTER_HORIZONTAL
        }
        root.addView(TextView(this).apply {
            text = "JARVIS AI"
            textSize = 30f
            gravity = Gravity.CENTER
        }, match(ViewGroup.LayoutParams.MATCH_PARENT, -2))
        root.addView(TextView(this).apply {
            text = "Your personal voice assistant"
            textSize = 14f
            gravity = Gravity.CENTER
        })

        provider = Spinner(this)
        provider.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            listOf("OpenAI", "Google Gemini"))
        root.addView(label("AI Provider"))
        root.addView(provider, match(-1, -2))

        root.addView(label("API key (used only in this app session)"))
        apiKey = EditText(this).apply {
            hint = "Paste your OpenAI or Gemini API key"
            inputType = 129
        }
        root.addView(apiKey, match(-1, -2))

        root.addView(label("Ask JARVIS"))
        question = EditText(this).apply {
            hint = "Type a question or tap Speak"
            minLines = 2
            gravity = Gravity.TOP
        }
        root.addView(question, match(-1, -2))

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(Button(this).apply {
            text = "🎙 Speak"
            setOnClickListener { startVoiceInput() }
        }, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(Button(this).apply {
            text = "Ask AI"
            setOnClickListener { askJarvis() }
        }, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(row)

        root.addView(Button(this).apply {
            text = "Open an app"
            setOnClickListener { showApps() }
        }, match(-1, -2))

        root.addView(label("JARVIS response"))
        answer = TextView(this).apply {
            text = "Hello! I am JARVIS. Choose an AI provider and add its API key to begin."
            textSize = 16f
            setPadding(12, 16, 12, 16)
        }
        val scroll = ScrollView(this)
        scroll.addView(answer)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun match(w: Int, h: Int) = LinearLayout.LayoutParams(w, h)
    private fun label(s: String) = TextView(this).apply {
        text = s; textSize = 14f; setPadding(0, 14, 0, 4)
    }

    private fun startVoiceInput() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 41)
            return
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to JARVIS")
        }
        try { startActivityForResult(intent, 42) }
        catch (_: Exception) { answer.text = "Voice recognition is not available on this device." }
    }

    @Deprecated("Use Activity Result API in a production app")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 42 && resultCode == Activity.RESULT_OK) {
            question.setText(data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull() ?: "")
        }
    }

    private fun askJarvis() {
        val key = apiKey.text.toString().trim()
        val prompt = question.text.toString().trim()
        if (key.isEmpty()) { answer.text = "Please enter your API key."; return }
        if (prompt.isEmpty()) { answer.text = "Please type or speak a question."; return }
        answer.text = "JARVIS is thinking..."
        scope.launch {
            try {
                val result = withContext(Dispatchers.IO) {
                    if (provider.selectedItemPosition == 0) askOpenAI(key, prompt)
                    else askGemini(key, prompt)
                }
                answer.text = result
                if (ttsReady) tts.speak(result, TextToSpeech.QUEUE_FLUSH, null, "jarvis")
            } catch (e: Exception) {
                answer.text = "Request failed: ${e.message ?: "Unknown error"}\nCheck your internet connection, API key and provider quota."
            }
        }
    }

    private fun askOpenAI(key: String, prompt: String): String {
        val body = JSONObject().put("model", "gpt-4o-mini")
            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", prompt)))
        val req = Request.Builder().url("https://api.openai.com/v1/chat/completions")
            .addHeader("Authorization", "Bearer $key")
            .post(body.toString().toRequestBody("application/json".toMediaType())).build()
        client.newCall(req).execute().use { response ->
            val raw = response.body?.string().orEmpty()
            if (!response.isSuccessful) error("OpenAI ${response.code}: $raw")
            return JSONObject(raw).getJSONArray("choices").getJSONObject(0)
                .getJSONObject("message").getString("content")
        }
    }

    private fun askGemini(key: String, prompt: String): String {
        val body = JSONObject().put("contents", JSONArray().put(
            JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt)))))
        val req = Request.Builder()
            .url("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=$key")
            .post(body.toString().toRequestBody("application/json".toMediaType())).build()
        client.newCall(req).execute().use { response ->
            val raw = response.body?.string().orEmpty()
            if (!response.isSuccessful) error("Gemini ${response.code}: $raw")
            return JSONObject(raw).getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
        }
    }

    private fun showApps() {
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(intent, 0)
            .sortedBy { it.loadLabel(pm).toString().lowercase() }
        val names = apps.map { it.loadLabel(pm).toString() }
        if (names.isEmpty()) return
        AlertDialog.Builder(this).setTitle("Choose an app")
            .setItems(names.toTypedArray()) { _, which ->
                val launch = pm.getLaunchIntentForPackage(apps[which].activityInfo.packageName)
                if (launch != null) startActivity(launch)
            }.show()
    }

    override fun onInit(status: Int) {
        ttsReady = status == TextToSpeech.SUCCESS
        if (ttsReady) tts.language = Locale("hi", "IN")
    }

    override fun onDestroy() {
        scope.cancel()
        if (::tts.isInitialized) tts.shutdown()
        super.onDestroy()
    }
}
